# Pupper IMU Code
Reads orientation data from the Sparkfun BNO080 breakout board and then pipes them to the RaspberryPi over USB serial. 
