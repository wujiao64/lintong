# QuadrupedController
A library to control 12dof, position-based quadruped robots.
