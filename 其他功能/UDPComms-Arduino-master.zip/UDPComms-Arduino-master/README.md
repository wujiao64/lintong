
UDPComms-Arduino
-----------------

Attempt to allow an arduino with an Ethernet shield to send and receive packets just like the python UDPComms library

Work in Progress
